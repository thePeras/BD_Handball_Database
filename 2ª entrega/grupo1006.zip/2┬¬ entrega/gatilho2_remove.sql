DROP TRIGGER IF EXISTS VerificarInscricaoJogador;
