DROP TRIGGER IF EXISTS VerificarGoloEquipa;
DROP TRIGGER IF EXISTS VerificarPausaTecnicaEquipa;
