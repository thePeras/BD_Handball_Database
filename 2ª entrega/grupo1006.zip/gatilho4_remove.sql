DROP TRIGGER IF EXISTS VerificarGoloAtleta;
DROP TRIGGER IF EXISTS VerificarInterrupcaoAtleta;
