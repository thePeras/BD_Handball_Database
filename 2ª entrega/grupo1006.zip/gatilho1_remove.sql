DROP TRIGGER IF EXISTS VerificarNrJornadas;
